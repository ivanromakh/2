import pygame
import math
from pygame import *
import random

from settings import *
from bullet import Bullets
from objectmoving import *
from mygame4 import enzooming

class Player():
    def __init__(self, x, y, whoIam, ispart, ptype):

        
        self.center = [x, y, 0]

        self.alfa = 0
        self.beta = 0
        
        self.speed = SPEED
        self.p1 = [self.center[0] - ZOOM2, self.center[1], 0]
        self.p2 = [self.center[0] + ZOOM2, self.center[1]- ZOOM2, 0]
        self.p3 = [self.center[0] + ZOOM2, self.center[1] + ZOOM2, 0]

        #for rotation
        self.p4 = [self.center[0], self.center[1]-ZOOM2, 0]
        self.p5 = [self.center[0], self.center[1]+ZOOM2, 0]
        #print p1, p2, p3, p4, p5
        self.points = [self.p1, self.p2, self.p3]
        
        self.p6 = [self.center[0]+ZOOM2, self.center[1], ZOOM2/2]
        self.p7 = [self.center[0]+ZOOM2, self.center[1], -ZOOM2/2]

        self.myposx = 0.0
        self.myposy = 0.0

        self.spvec = [0.0, 0.0]

        self.ismoveup = False
        self.ismovedown = False

        self.isrotateleft = False
        self.isrotateright = False

        self.isrotateup = False
        self.isrotatedown = False
            
    # draw poligon and cannon
    def draw(self, screen, pos, scale):
        x = enzooming(self.points, self.center, scale)
        x[0] = rotatepoint3d(self.center, self.points[0], self.beta)

        center1 = rotatepoit(self.center, self.p4, self.alfa)
        center2 = rotatepoit(self.center, self.p5, self.alfa)
        
        x[1] = rotatepoint3d(center1, self.points[1], self.beta)
        x[2] = rotatepoint3d(center2, self.points[2], self.beta)
        pygame.draw.polygon(screen, PL_COLOR, x)
        xx = rotatepoit((self.center[0],self.center[2]), (self.p7[0], self.p7[2]), self.beta)
        xy = rotatepoit((self.center[0],self.center[2]), (self.p6[0], self.p6[2]), self.beta)
        xx[0] = int(xx[0])
        xx[1] = int(xx[1])
        xy[0] = int(xy[0])
        xy[1] = int(xy[1])
        print xx, self.p7, xy, self.p6
        if self.beta>=0 and self.beta<=180:
            pygame.draw.lines(screen, (255,0,0), True, (x[1], (xx[0], self.p7[1]), x[2], (xy[0], self.p6[1])), 3)
            pygame.draw.polygon(screen, (0,0,0), (x[1], (xx[0], self.p7[1]), x[2], (xy[0], self.p6[1])))
        elif self.beta>=-360 and self.beta<=-180:
            pygame.draw.lines(screen, (255,0,0), True, (x[1], (xx[0], self.p7[1]), x[2], (xy[0], self.p6[1])), 3)
            pygame.draw.polygon(screen, (0,0,0), (x[1], (xx[0], self.p7[1]), x[2], (xy[0], self.p6[1])))
        elif self.beta>180 and self.beta<360:
            pygame.draw.lines(screen, (255,0,0), True,(x[1], (xx[0], self.p7[1]), x[2], (xy[0], self.p6[1])), 3)
            pygame.draw.polygon(screen, PL_COLOR, (x[1], (xx[0], self.p7[1]), x[2], (xy[0], self.p6[1])))
        elif self.beta>-180 and self.beta<0:
            pygame.draw.lines(screen, (255,0,0), True,(x[1], (xx[0], self.p7[1]), x[2], (xy[0], self.p6[1])), 3)
            pygame.draw.polygon(screen, PL_COLOR, (x[1], (xx[0], self.p7[1]), x[2], (xy[0], self.p6[1])))

    # move on map, change zoom, rotate all objects and player
    def update(self, speed, zoom, player):
        if self.isrotateleft == True:
            self.rotate(-1)
        if self.isrotateright == True:
            self.rotate(1)
        if self.isrotateup == True:
            if self.beta>360:
                self.beta-=360
            self.beta+=BETA
            
        if self.isrotatedown == True:
            if self.beta<-360:
                self.beta += 360

            self.beta-=BETA    
            
    # rotate object around the center    
    def rotate(self, x):
        alfa = 0
        self.isrotated = True
        # increase all point angles
        if x>0:
            self.alfa += ALFA
            alfa = ALFA
        elif x<0:
            self.alfa -= ALFA
            alfa = -ALFA
        if alfa != 0:
            self.points = rotatepoints(self.center, self.points, alfa)



