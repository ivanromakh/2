import random 
import pygame
from   pygame.locals import *
import sys
import pickle
from time import sleep
import socket

import player
from player import* 
from settings import *
from pygame import *
from menu import Menu, mennu
from minimap import Minimap
from MyButtons import createbuttons, update_display
from createmode import startpause, createmode
from shild import shild_dam, shild_rest
from bullet import Bullets
from objectmoving import rotatepoints, movepl
from zoomdraws import*

    
# main function
def main():
    pygame.init()
    # menu check server or client
    mennu()
    scale = 1
    #draw displey
    screen = pygame.display.set_mode(DISPLAY) 
    # get player start position
    midx = WIN_WIDTH/2
    midy = WIN_HEIGHT/2
    #create this user and group of his parts 
    myplayer = player.Player(midx, midy, True, False, CANNON)
    play_parts = []
    play_parts.append(myplayer)
    #this user bullets
    player_bul = []
    zoom1 = ZOOM + 0.0
    # clock for fps
    timer = pygame.time.Clock()
    
    # zoom press
    iszoomincres = False
    iszoomdecres = False

    while True:
        pos = mouse.get_pos()
        screen.fill(BACKGROUND_COLOR)
        
        # if zoom pressed zoom increes
        if iszoomincres == True:
            if scale<MAXSCALE:
                zoom1 += 2
                scale = zoom1/ZOOM
        # if zoom pressed zoom decrease        
        elif iszoomdecres == True:
            if scale>MINSCALE:
                zoom1 -= 2
                scale = zoom1/ZOOM
            
        #update, add to send list and draw thisplayer parts 
        myplayer.update(0, 1, myplayer)
        myplayer.draw(screen, pos, scale)
        # ALL EVENTS for gamemode
        for e in pygame.event.get():
            # check multipress 
            keystate = pygame.key.get_pressed()
        
            # exit
            if e.type == QUIT:
                #sock.close()
                pygame.quit()
                sys.exit()
     
            # start moving and rotating
            elif e.type == KEYDOWN:
                if keystate[K_ESCAPE]:
                    pygame.quit()
                    sys.exit()
                if keystate[K_RSHIFT]:
                    print "shift"
                    for part in play_parts:
                        part.ismoveup = True
                if keystate[K_DOWN]:
                    for part in play_parts:
                        part.ismovedown = True
                if keystate[K_LEFT]:
                    for part in play_parts:
                        part.isrotateleft = True
                if keystate[K_RIGHT]:
                    for part in play_parts:
                        part.isrotateright = True

                if keystate[K_UP]:
                    myplayer.isrotateup = True
                if keystate[K_DOWN]:
                    myplayer.isrotatedown = True
                if keystate[K_1]:
                    iszoomincres = True
                if keystate[K_2]:
                    iszoomdecres = True

            # stop moving and rotating        
            elif e.type == KEYUP:
                if e.key == K_UP:
                    myplayer.isrotateup = False
                if e.key == K_DOWN:
                    myplayer.isrotatedown = False    
                if e.key == K_RSHIFT:
                    for part in play_parts:
                        part.ismoveup = False
                
                if e.key == K_LEFT:
                    for part in play_parts:
                        part.isrotateleft = False
                if e.key == K_RIGHT:
                    for part in play_parts:
                        part.isrotateright = False
                if e.key == K_1:
                    iszoomincres = False
                if e.key == K_2:
                    iszoomdecres = False

     
        drawtext(screen, timer)
        pygame.display.flip()

# main fuction                
if __name__ == "__main__":
    main()
    
