import math
import pygame
from pygame import *

from settings import *

# rotate point 3d
def rotatepoint3d(c, point, r):
    s = math.sin(r*math.pi/180)
    cs = math.cos(r*math.pi/180)
    respoints = []
    #vectors
    tempx = point[0] - c[0]
    tempy = point[1] - c[1]
    #tempz = point[2] - c[2]
    #radius
    tempxy = ZOOM2
    
    # zmichennia
    newxy = tempxy*cs
    z = tempxy*s

    x = newxy*tempx/ZOOM2
    y = newxy*tempy/ZOOM2
    return (c[0]+x,c[1]+y)

# rotate point 2d
def rotatepoit(c, point, r):
    s = math.sin(r*math.pi/180)
    cs = math.cos(r*math.pi/180)
    respoints = []
    tempx = point[0] - c[0]
    tempy = point[1] - c[1]
        
    # zmichennia
    x = tempx*cs - tempy*s
    y = tempx*s + tempy*cs
    
    #update distance 
    respoints.append(c[0] + x)
    respoints.append(c[1] + y)
    return respoints

# rotate all points in polligon around the center 2d   
def rotatepoints(c, points, r):
    s = math.sin(r*math.pi/180)
    cs = math.cos(r*math.pi/180)
    respoints = []
    for p in points:
        # distance 
        tempx = p[0] - c[0]
        tempy = p[1] - c[1]
        
        # zmichennia
        x = tempx*cs - tempy*s
        y = tempx*s + tempy*cs
        
        #update distance 
        respoints.append([c[0] + x, c[1] + y, p[2]])
    return respoints

#shifh from player to some distance  
def movepl(p, x, y):
    p[0] = p[0] - x
    p[1] = p[1] - y
    return p
