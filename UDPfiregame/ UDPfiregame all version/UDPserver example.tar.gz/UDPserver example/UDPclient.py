import socket
import sys

HOST, PORT = "localhost", 8888
data = "xxxxx"
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.connect((HOST, PORT))
        
while True:
    # Connect to server and send data
    sock.sendall(data + "\n")

    # Receive data from the server and shut down
    received = sock.recv(1024)
    print "Received: %s"%received
