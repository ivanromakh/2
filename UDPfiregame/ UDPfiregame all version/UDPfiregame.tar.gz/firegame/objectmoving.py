import math
import pygame
from pygame import *


from settings import *

# rotate all points in polligon around the center    
def rotatepoints(c, points, r):
    s = math.sin(r*math.pi/180)
    cs = math.cos(r*math.pi/180)
    respoints = []
    for p in points:
        # distance 
        tempx = p[0] - c[0]
        tempy = p[1] - c[1]
        
        # zmichennia
        x = tempx*cs - tempy*s
        y = tempx*s + tempy*cs
        
        #update distance 
        respoints.append([c[0] + x, c[1] + y])
    return respoints




#zooming all points in poligon
def pointzoom(points, c, zooming, zoom):
    respoint = []
    for p in points:
        tempx = p[0] - c[0]
        tempy = p[1] - c[1]
    
        x = p[0]
        y = p[1]
        if zooming>0:
            x += tempx - tempx*KOF
            y += tempy - tempy*KOF
        else:
            x += tempx - tempx*(2-KOF)
            y += tempy - tempy*(2-KOF)
            
        respoint.append([x,y])
    return respoint  



# shift all points of poligon the map
def shiftpoint(x, y, points, zooming, alfa):

    tempx = 0.0
    tempy = 0.0
        
    if zooming> 0:
        if x!=0:
            tempx += x*math.cos(alfa*math.pi/180)
            tempy += x*math.sin(alfa*math.pi/180)  
        if y!=0:
            tempy += y*math.cos(alfa*math.pi/180)
            tempx += -y*math.sin(alfa*math.pi/180)  
            
    if zooming< 0:
        if x!=0:
            tempx += -x*math.cos(alfa*math.pi/180)
            tempy += -x*math.sin(alfa*math.pi/180) 
        if y!=0:
            tempy += -y*math.cos(alfa*math.pi/180)
            tempx += y*math.sin(alfa*math.pi/180)
    respoints = []        
    for p in points:
        x = p[0] + tempx
        y = p[1] + tempy
        respoints.append([x, y])
    return respoints

# find distance to player center for all points in ppoligon
def finddis(points, center):
    dis = []
    for p in points: 
        dis.append([p[0]-center[0], p[1]-center[1]])
    return dis

# find distance update for all points in polligon
def newdis(distance, xy):
    dist = []
    if xy<0:
        for dis in distance:
            dis[0] = dis[0] - dis[0]*(2-KOF)
            dis[1] = dis[1] - dis[1]*(2-KOF)
            dist.append([dis[0], dis[1]])
    else:
        for dis in distance:
            dis[0] = dis[0] - dis[0]*KOF
            dis[1] = dis[1] - dis[1]*KOF
            dist.append([dis[0], dis[1]])
    return dist    

# for all points in poligon
def newvectors(points, distance):
    i = 0
    respoints = []                      
    for p in points:
        x = p[0]+distance[i][0]+0.0
        y = p[1]+distance[i][1]+0.0
        i+=1
        respoints.append([x, y])  
    return respoints

# calculate rect center  
def findcent(c, p, alfa, zoom):
     x = zoom*math.cos(alfa*math.pi/180)/2
     y = zoom*math.sin(alfa*math.pi/180)/2
     cy = 0.0
     # where alfa = 90, 180, ... where cos and sin uncorect                 
     cx = p[0] - zoom/2 +  x
     if alfa%90 != 0:
         cy = p[1] - zoom/2 + y
     elif alfa%180 == 1:
         cy  = p[1] - zoom/2
     elif alfa%90 == 1:
         cy  = p[1]
     return (cx, cy)    
