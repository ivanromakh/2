import threading
import socket
import logging
import pickle

from settings import*

clients_lock = threading.Lock()

class Broker():

    def __init__(self):
        logging.info('Initializing Broker')
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((HOST, PORT))
        self.i = 0
        self.recpl = []
        self.recbull = []

    def talkToClient(self, ip):
        data = "PL"
        data += pickle.dumps(self.recpl)
        data += "BUL"
        data += pickle.dumps(self.recbull)
        print "-------"
        print self.recbull
        self.sock.sendto(data, ip)

    def listen_clients(self):
        while True:
            msg, client = self.sock.recvfrom(1024)
            self.decode(msg, self.recpl)
            t = threading.Thread(target=self.talkToClient, args=(client,))
            t.start()

    def decode(self, msg, plcords):
        # if this is player cords
        if msg[0:2] == "PL":
            msg = msg[2:]
            cords = msg.split("BUL")


            #players
            player = pickle.loads(cords[0])
            for pl in self.recpl:
                if player[3] == pl[3]:
                    self.recpl.remove(pl)
            self.recpl.append(player)


            #bullets
            bullets = pickle.loads(cords[1])
            for cor in bullets:
                for b in self.recbull:
                    if cor[3] == b[3]:
                        if cor[2] == b[2]:
                            self.recbull.remove(b)
                self.recbull.append(cor)
            

        

                             
if __name__ == '__main__':
    # Make sure all log messages show up
    logging.getLogger().setLevel(logging.DEBUG)
    print "start", HOST, PORT
    b = Broker()
    b.listen_clients()
