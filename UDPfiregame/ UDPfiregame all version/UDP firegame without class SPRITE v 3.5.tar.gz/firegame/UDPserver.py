import threading
import socket
import logging
import pickle
import pygame
import random
import math


from settings import*
import player

clients_lock = threading.Lock()

class Server():
    def __init__(self):
        logging.info('Initializing Broker')

        pygame.init()

        self.recpl = []
        self.recbull = []
        self.sendenbul = []

        self.senden = []
        self.sendkilen = []
        
        self.clients = [[]]
        self.clientsend = []
        
        self.count = 0
        self.clientnum = 0
        
        self.en = pygame.sprite.Group()
        self.en_bul = pygame.sprite.Group()

        self.speed = 0        

        pygame.time.set_timer(ENEMYRATE, 3000)
        pygame.time.set_timer(EN_FIRE, 500)
    
    def enmove(self):
        # enemy updates
        for e in self.en:
            x = 6
            x = int(x*random.random())

            if x == 0:
                e.update(-1,1, 0)
                self.senden.remove(e.sendp)
                e.shiftmove()
                self.senden.append(e.sendp)

            if x == 1:
                e.rotate(1, 0)
                self.senden.remove(e.sendp)
                e.shiftmove()
                self.senden.append(e.sendp)

            if x >= 2 and x <=5:
                e.update(1,1, 0)
                self.senden.remove(e.sendp)
                e.shiftmove()
                self.senden.append(e.sendp)

            if x == 6:
                e.rotate(1, 0)
                self.senden.remove(e.sendp)
                e.shiftmove()
                self.senden.append(e.sendp)

    def EnemyandShot(self):
            for e in pygame.event.get():
                if e.type ==  ENEMYRATE:
                    myenemy = player.Player(
                        int(WIN_WIDTH/ZOOM*random.random()),
                        int(WIN_HEIGHT/ZOOM*random.random()),
                        False, False, CANNON)
                    
                    self.senden.append(myenemy.sendp)
                    self.en.add(myenemy)

                # enemy shoot
                if e.type == EN_FIRE:
                    for myen in self.en:
                        for pl in self.recpl:
                            x = myen.points[0][0]-pl[0][0]
                            y = myen.points[0][1]-pl[0][1]
                            if math.sqrt(pow(x,2)+pow(y,2)) < myen.radius:
                                
                                self.sendenbul.append([myen.center,
                                                       [pl[0][0], pl[0][1]]])                                    
                                break

    # add client and bool (send to them or not right now) to list 
    def addclient(self, client):
        ishere = False
        for cl in self.clients:
            if cl != []:
                if client == cl[0]:
                    ishere = True
        if ishere == False:
            self.clients.append([client, False])

    #if sended to all return True another False 
    def is_sendtoall(self, client):

        # in this client set status sended True
        for cl in self.clients:
            if cl != []:
                if cl[0] == client:
                    cl[1] = True

        # check if all status is True
        alltrue = True         
        for cl in self.clients:
            if cl !=[]:
                if cl[1] == False: 
                    alltrue = False         
        return alltrue    

    #if sended to all return status to false
    def alltofalse(self, alltrue):
        if alltrue == True:
            del self.sendenbul[:] 
            for cl in self.clients:
                if cl !=[]:
                    cl[1] = False
                    
    # recive data and run send thread
    def listen_clients(self, sock):
        while True:
            #recive data    
            msg, client = sock.recvfrom(5000)
            #add to client list if client isn't there
            self.addclient(client)
            #return True is sended to all
            alltrue = self.is_sendtoall(client)
            # decode data

            self.decode(msg)
            #start thread send to client

            self.EnemyandShot()
            self.enmove()
            
            data = "PL"
            data += pickle.dumps(self.recpl)
            data += "BUL"
            data += pickle.dumps(self.recbull)
            data += "ENE"
            data += pickle.dumps(self.senden)
            data += "KIL"
            data += pickle.dumps(self.sendkilen)
            data += "ENB"
            print self.sendenbul
            data += pickle.dumps(self.sendenbul)
            #send data
            sock.sendto(data, client)
            #if sended to clear status of all clients 
            self.alltofalse(alltrue)
            
    # take data from message(package)
    def decode(self, msg):
        # if this is player cords
        if msg[0:2] == "PL":
            msg = msg[2:]
            cords = msg.split("BUL")
            #players
            player = pickle.loads(cords[0])
            ishere = False
            for pl in self.recpl:
                if player[3] == pl[3]:
                    self.recpl.remove(pl)
            self.recpl.append(player)
            cords = cords[1].split("DAM")
            #bullets
            bullets = pickle.loads(cords[0])
            for cor in bullets:
                for b in self.recbull:
                    if cor[3] == b[3]:
                        if cor[2] == b[2]:
                            self.recbull.remove(b)
                self.recbull.append(cor)
            cords = cords[1].split("PAR")
            #damage
            damage = pickle.loads(cords[0])
            for e in self.en:
                for dam in damage:
                    if e.id == dam:
                        if len(self.sendkilen) < 3:
                            self.sendkilen.append(e.id)
                        else:
                            self.sendkilen.remove(self.sendkilen[0])
                            self.sendkilen.append(e.id)
                        self.senden.remove(e.sendp)
                        e.kill()
            parts =  pickle.loads(cords[1])           
                            
if __name__ == '__main__':
    print "start", HOST, PORT
    Ser = Server()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((HOST, PORT))
    t = threading.Thread(target=Ser.listen_clients(sock).start())
    
