import pygame
import math

from settings import ZOOM, BUL_SIZE, PL_COLOR, CAN_COLOR, CAN_SIZE
from objectmoving import rotatepoints

#find squere of enemy on the map 
def findsquere(encord):
    xmin = encord[0][0]-ZOOM/2
    xmax = encord[0][0]+ZOOM/2
    ymin = encord[0][1]-ZOOM/2
    ymax = encord[0][1]+ZOOM/2
    return (xmin, xmax, ymin, ymax)

def drawscbull(screen, (x, y), scale):
    pygame.draw.circle(screen, (250,0,250), (x, y), int(BUL_SIZE*scale) , int(BUL_SIZE*scale))

def drawmyen(screen, pos, alfa, myplcent, scale, color):
    tcords = []
    tcords.append([pos[0] - ZOOM/2, pos[1]])
    tcords.append([pos[0] + ZOOM/2, pos[1] - ZOOM/2])
    tcords.append([pos[0] + ZOOM/2, pos[1] + ZOOM/2])
    points = rotatepoints(pos, tcords, alfa)
    points = mypoints(points, myplcent, scale)
    pygame.draw.polygon(screen, color, (points))

def drawmypl(screen, pos, alfa, myplcent, scale, color, canpos):
    tcords = []
    tcords.append([pos[0] - ZOOM/2, pos[1]])
    tcords.append([pos[0] + ZOOM/2, pos[1] - ZOOM/2])
    tcords.append([pos[0] + ZOOM/2, pos[1] + ZOOM/2])

    points = rotatepoints(pos, tcords, alfa)
    points = mypoints(points, myplcent, scale)
    pygame.draw.polygon(screen, color, (points))

       
    center = pos
    
    x = canpos[0]-center[0]
    y = canpos[1]-center[1]
    r = math.sqrt(math.pow(x, 2)+ math.pow(y, 2))
    if r!=0:
        y = int((y*ZOOM*scale)/r)
        x = int((x*ZOOM*scale)/r)
        pygame.draw.line(screen, CAN_COLOR, center, (center[0]+x, center[1]+y), CAN_SIZE*scale)


def drawpoligon(screen, pos):
    pygame.draw.polygon(screen, PL_COLOR, ((pos[0] - ZOOM/2, pos[1]),
                                           (pos[0] + ZOOM/2, pos[1] - ZOOM/2),
                                           (pos[0] + ZOOM/2, pos[1] + ZOOM/2)))

def drawrect(screen, pos):
    pygame.draw.polygon(screen, PL_COLOR, ((pos[0] - ZOOM/2, pos[1] - ZOOM/2),
                                           (pos[0] - ZOOM/2, pos[1] + ZOOM/2),
                                           (pos[0] + ZOOM/2, pos[1] + ZOOM/2),
                                           (pos[0] + ZOOM/2, pos[1] - ZOOM/2)))

# draw information and fps  
def drawtext(screen, timer):
    mytext = pygame.font.SysFont("monospace", 15)
    timer.tick(60)
    text = mytext.render("FPS "+str(timer.get_fps()), 1, (10, 10, 10))
    screen.blit(text, (5, 160))

#zooming recived players objects
def enzooming(obj, center, scale):
    dis = mypoints(obj, center, scale)
    return dis

#zooming bullet
def bzooming(obj, center, x, y, scale):
    dis = mypoint(obj, center, x, y, scale)
    return dis

#shift points by player moving and zooming
def mypoints(points, center, scale):
    newp = []
    for p in points: 
        newp.append((int(center[0]+((p[0]-center[0])*scale)), int(center[1]+((p[1]-center[1])*scale))))
    return newp

#shift point by player moving and zooming
def mypoin(p, center, scale):
    return (int(center[0]+((p[0]-center[0])*scale)), int(center[1]+((p[1]-center[1])*scale)))


#shift point by player moving and zooming
def mypoint(p, center, x, y, scale):
    return (int(center[0]+((p[0]-center[0]-x)*scale)), int(center[1]+((p[1]-center[1]-y)*scale)))
