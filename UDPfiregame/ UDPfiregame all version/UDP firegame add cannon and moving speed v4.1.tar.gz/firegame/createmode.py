import pygame
from pygame import *
import player
from settings import *
from shild import shild_dam, shild_rest

# start create object mode
def createmode(screen, p, pausa, cannon, shild, pos, upispres, parts, zoom, kof, myplayer):
    create = 0
    for e in pygame.event.get():
        if e.type == pygame.MOUSEBUTTONDOWN:     
            if pausa.pressed(pos):
                p = False
            elif cannon.pressed(pos):
                upispres=CANNON
            elif shild.pressed(pos):
                upispres=SHILD    
        
        if e.type == pygame.MOUSEBUTTONUP:
            if upispres > 0:
                squeres = []
                ishere  = False
                print "mouse", pos[0], pos[1]
                for part in parts:
                    squeres.append([[part.center[0]-ZOOM2, part.center[1]-ZOOM2],
                                   [part.center[0]+ZOOM2, part.center[1]+ZOOM2]])

                # if under mouse is a part of player end of event 
                for squere in squeres:
                    if pos[0]>= squere[0][0] and pos[0]<= squere[1][0]:
                        print "s1"
                        if pos[1]>= squere[0][1] and pos[1]<= squere[1][1]:
                            ishere = True
                            print "not evaible"
                            
                # if under mouse isn't any parts             
                if ishere == False:         
                    print "good"
                    for part in parts:
                        if pos[0]>= part.center[0]-ZOOM2-ZOOM and pos[0]<= part.center[0]-ZOOM2:
                            if pos[1]>= part.center[1]-ZOOM2 and pos[1]<= part.center[1]+ZOOM2:
                                pl = player.Player(part.center[0]-zoom, part.center[1], True, True, upispres)
                                pl.partposx = part.partposx - 1 
                                pl.partposy = part.partposy
                                print "cord", pl.partposx,  pl.partposy
                                upispres=0
                                return (p, upispres, pl)
                                
                        if pos[0]>= part.center[0]+ZOOM-ZOOM/2 and pos[0]<= part.center[0]+ZOOM + ZOOM/2:
                            if pos[1]>= part.center[1]-ZOOM2 and pos[1]<= part.center[1]+ZOOM2:
                                pl = player.Player(part.center[0]+ZOOM, part.center[1], True, True, upispres)
                                pl.partposx = part.partposx + 1
                                pl.partposy = part.partposy
                                print "cord", pl.partposx,  pl.partposy
                                upispres=0
                                return (p, upispres, pl)
                        if pos[0] >= part.center[0] - ZOOM2 and pos[0] <= part.center[0] + ZOOM2:
                            if pos[1]>= part.center[1]+ZOOM2 and pos[1]<= part.center[1]+ZOOM + ZOOM/2:
                                pl = player.Player(part.center[0], part.center[1]+ZOOM, True, True, upispres)
                                pl.partposx = part.partposx  
                                pl.partposy = part.partposy + 1
                                print "cord", pl.partposx,  pl.partposy
                                upispres=0
                                return (p, upispres, pl)
                        if pos[0]>= part.center[0]-ZOOM2 and pos[0]<= part.center[0]+ZOOM2:
                            if pos[1]>= part.center[1]-ZOOM-ZOOM2 and pos[1]<= part.center[1]-ZOOM2:
                                pl = player.Player(part.center[0], part.center[1]-ZOOM, True, True, upispres)
                                pl.partposx = part.partposx  
                                pl.partposy = part.partposy - 1
                                print "cord", pl.partposx,  pl.partposy
                                upispres=0
                                return (p, upispres, pl)    
            upispres=0
    return (p, upispres, 0)
    
# pause start 
def startpause(p, pausa, pos):
    if pausa.pressed(pos):
        print "paysa"
        p = True
    return p
