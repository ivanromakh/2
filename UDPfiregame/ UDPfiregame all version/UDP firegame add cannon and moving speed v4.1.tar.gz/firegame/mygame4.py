import random 
import pygame
from   pygame.locals import *
import sys
import pickle
from time import sleep
import socket

import player
from player import* 
from settings import *
from pygame import *
from menu import Menu, mennu
from minimap import Minimap
from MyButtons import createbuttons, update_display
from createmode import startpause, createmode
from shild import shild_dam, shild_rest
from bullet import Bullets
from objectmoving import rotatepoints, movepl
from zoomdraws import*

    
# main function
def main():
    pygame.init()
    # menu check server or client
    mennu()
    #zoom    
    zoom = ZOOM
    kof = 0
    scale = 1
    #draw displey
    screen = pygame.display.set_mode(DISPLAY) 
    # minimap
    minimap = Surface((MINIMAPSIZE,MINIMAPSIZE))
    # minimap create
    minmap = Minimap()
    # get player start position
    midx = WIN_WIDTH/2
    midy = WIN_HEIGHT/2
    #create this user and group of his parts 
    myplayer = player.Player(midx, midy, True, False, CANNON)
    play_parts = []
    play_parts.append(myplayer)
    #this user bullets
    player_bul = []
    zoom1 = ZOOM + 0.0
    # clock for fps
    timer = pygame.time.Clock()
    
    # zoom press
    iszoomincres = False
    iszoomdecres = False
        
    # socket create
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.connect((HOST, PORT))

    #Buttons
    upispres = 0
    p = False
    pausa = createbuttons()
    cannon = createbuttons()
    shild = createbuttons()
    # lists for reciven and sending 
    recivepl = []
    reciveen = []
    reckilen = []
    mustdelete = []
    damagesend = []
    sendparts = []
    mybulsend = []
    enemybul = []
    # send list of this user bullets
    data = ""
    while True:
        pos = mouse.get_pos()
            #DRAW ONLY THAT WHAT you scan see
        #x = WIN_WIDTH*scale-WIN_WIDTH
        #y = WIN_HEIGHT*scale-WIN_HEIGHT
        #startscreen = [myplayer.myposx+x, myplayer.myposy+y]
        #endscreen = [WIN_WIDTH+myplayer.myposx-x, WIN_HEIGHT+myplayer.myposy-y]
        #draw background on the screen 
        screen.fill(BACKGROUND_COLOR)
        
        # if zoom pressed zoom increes
        if iszoomincres == True:
            if scale<MAXSCALE:
                zoom1 += 2
                scale = zoom1/ZOOM
        # if zoom pressed zoom decrease        
        elif iszoomdecres == True:
            if scale>MINSCALE:
                zoom1 -= 2
                scale = zoom1/ZOOM
        
            #SHILD
        # check shilds
        #shild_dam((0,0), play_parts)
        # shild restore
        #shild_rest(play_parts)
        i=0 
        for bul in enemybul:
            if bul.updat()==-1:
                del enemybul[i]
            x = bzooming(bul.cords, myplayer.center, myplayer.myposx, myplayer.myposy, scale)
            drawscbull(screen, x, scale)
            i+=1

             
        # SHOTTING and all for this player bullets
        # draw and killed enemies
        mybulsend = []
        damagesend = []
        #update and draw bullets
        temp = False
        for bul in player_bul:
            if (bul.updat())!=-1:
                x = bzooming((bul.cords[0], bul.cords[1]), myplayer.center, 0, 0, scale)
                drawscbull(screen, x, scale)
                # check if bullet find a target
                for myen in reciveen:
                    #if bullet in the enemy squere kill bullet         
                    if bul.cords[0] >=  myen[0][0]-ZOOM/2 and bul.cords[0] <= myen[0][0]+ZOOM/2:
                        if bul.cords[1] >= myen[0][1]-ZOOM/2 and bul.cords[1] <= myen[0][1]+ZOOM/2:
                            damagesend.append(myen[2])
                            reciveen.remove(myen)
                            player_bul.remove(bul)
                            del bul
                            temp = True
                            break
                if temp==True:
                        break
                            
                #add bullet in send list    
                mybulsend.append((bul.cords[0]+int(myplayer.myposx), bul.cords[1]+int(myplayer.myposy), bul.id, bul.num))
            else:
                player_bul.remove(bul)
                
            #CREATE PACKAGE FOR SEND
        #send thisplayer package
        data = "PL"
        temp = []
        temp.append([int(myplayer.center[0]+ myplayer.myposx), int(myplayer.center[1]+ myplayer.myposy)])
        temp.append(myplayer.alfa)
        temp.append(myplayer.id)
        temp.append(False)
        temp.append([int(pos[0]+ myplayer.myposx),int(pos[1]+ myplayer.myposy)])
        #serialize thisplayer data
        data += pickle.dumps(temp)
        #serialize thisplayer bullets data   
        data += "BUL"
        data += pickle.dumps(mybulsend)
        #serialize damage of thisplayer bullets   
        data += "DAM"
        data += pickle.dumps(damagesend)
        data += "PAR"
        data += pickle.dumps(sendparts)
        
        #send and recive package
        sock.send(data)
        rec = sock.recv(BUFF)

        #DECODE PACKAGE
        if rec[:2] == "PL":
            rec = rec[2:]
            cords = rec.split("BUL")
            
            #take players data (center cords, alfa, player.id and other parts)
            players = pickle.loads(cords[0])
            for pl in players:
                if pl[0][2] != myplayer.id:
                    for play in recivepl:
                        # delete old data from list
                        if play[0][2] == pl[0][2]:
                            recivepl.remove(play)
                    recivepl.append(pl)

            cor = cords[1].split("ENE")
            
            #take bullet other player and zoomed
            bullets = pickle.loads(cor[0])
            if bullets != []:
                for b in bullets:
                    temp = False
                    for pl in play_parts:
                        if pl.id == b[2]:
                            temp = True
                    if temp == False:        
                        x = bzooming(b[:2], myplayer.center, myplayer.myposx, myplayer.myposy, scale)
                        drawscbull(screen, x, scale)

            co = cor[1].split("KIL")
            #take enemy cords
            enemies = pickle.loads(co[0])
            for enemy in enemies:
                enemy.append(False)
                for en in reciveen:
                    # delete old data from list
                    if en[2] == enemy[2]:
                        reciveen.remove(en)
                reciveen.append(enemy)

            cor = co[1].split("ENB")
            
            # take id killen enemies
            reckilen = pickle.loads(cor[0])

            #take enemy bullets and zoomed
            enbul = pickle.loads(cor[1])
            
            for b in enbul:
                enemybul.append(Bullets(b[0], b[1], 0, 0, 0))
        # move and draw recived players and parts of them 
        for p in recivepl:
            if p[0][3] == False:
                movepl(p[0][0], myplayer.myposx, myplayer.myposy)
                movepl(p[0][4], myplayer.myposx, myplayer.myposy)
                p[0][3] = True
                drawmypl(screen, p[0][0], p[0][1], myplayer.center, scale, PL_COLOR, p[0][4])
                #draw parts
                for part in p[1]:
                    movepl(part, myplayer.myposx, myplayer.myposy)
                    drawmypl(screen, part, p[0][1], myplayer.center, scale, PL_COLOR, p[0][4], )

            
        #update, add to send list and draw thisplayer parts 
        del sendparts[:]
        for pl in play_parts:
            pl.update(0, 1, myplayer)
            if pl.id == myplayer.id:
                pl.draw(screen, pos, scale)
            else:
                tempcent = rotatepoit(myplayer.center, pl.center, myplayer.alfa)
                sendparts.append([int(tempcent[0]+myplayer.myposx), int(tempcent[1]+myplayer.myposy)])
                x = enzooming(pl.points, myplayer.center, scale)
                pldraw(screen, x, PL_COLOR)

        for myen in reciveen:
            if myen[3] == False:
                myen[0] = movepl(myen[0], myplayer.myposx, myplayer.myposy)
                myen[3] = True
                drawmyen(screen, myen[0], myen[1], myplayer.center, scale, EN_COLOR)


        # ALL EVENTS for gamemode
        for e in pygame.event.get():
            # check multipress 
            keystate = pygame.key.get_pressed()
        
            # exit
            if e.type == QUIT:
                sock.close()
                pygame.quit()
                sys.exit()
 
            # start moving and rotating
            elif e.type == KEYDOWN:
                if keystate[K_ESCAPE]:
                    pygame.quit()
                    sys.exit()
                if keystate[K_UP]:
                    for part in play_parts:
                        part.ismoveup = True
                if keystate[K_DOWN]:
                    for part in play_parts:
                        part.ismovedown = True
                if keystate[K_LEFT]:
                    for part in play_parts:
                        part.isrotateleft = True
                if keystate[K_RIGHT]:
                    for part in play_parts:
                        part.isrotateright = True
                if keystate[K_1]:
                    iszoomincres = True
                if keystate[K_2]:
                    iszoomdecres = True

            # stop moving and rotating        
            elif e.type == KEYUP:
                if e.key == K_UP:
                    for part in play_parts:
                        part.ismoveup = False
                if e.key == K_DOWN:
                    for part in play_parts:
                        part.ismovedown = False
                if e.key == K_LEFT:
                    for part in play_parts:
                        part.isrotateleft = False
                if e.key == K_RIGHT:
                    for part in play_parts:
                        part.isrotateright = False
                if e.key == K_1:
                    iszoomincres = False
                if e.key == K_2:
                    iszoomdecres = False

            #player shoot        
            elif e.type == pygame.MOUSEBUTTONDOWN:

                # if button press (CREATEMODE)        
                if e.type == pygame.MOUSEBUTTONDOWN:
                    # mouse position
                    pos = pygame.mouse.get_pos()
                    p = startpause(p, pausa, pos)
                    
                    # if pausa reset all player objects angle
                    if p == True:
                        alfa = myplayer.alfa
                        if alfa%360!=0:
                            alfa = alfa%360
                            for part in play_parts:
                                part.alfa = 0
                                part.rottoanhle(-alfa, myplayer)
                                part.update(0, 1 , myplayer)
                               
                    #pausa createmode begin
                    while p == True:
                        sock.send(data)
                        rec = sock.recv(BUFF)
                        screen.fill((100,100,100))
                        update_display(screen, cannon, 100, 2, WIN_WIDTH/2)
                        update_display(screen, shild, 140, 2, WIN_WIDTH/2)
                        update_display(screen, pausa, 10, 2, 0)
                        
                        pos = pygame.mouse.get_pos()
                        (p,upispres, mypl) = createmode(screen, p, pausa, cannon, shild, pos, upispres, play_parts, ZOOM, kof, myplayer)
                        
                        if mypl != 0:
                            play_parts.append(mypl)
                        if upispres == CANNON:
                            drawpoligon(screen, pos)
                        elif upispres == SHILD:
                            drawrect(screen, pos)
                        for pl in play_parts:
                            pl.draw(screen, pos, 1)
                        
                        pygame.display.flip()
                
                # player shoot
                for pl in play_parts:
                    if pl.ptype == CANNON:
                        player_bul.append(pl.shoot(pos))
        #pausa button                
        update_display(screen, pausa, 10, 1,0)        

        drawtext(screen, timer)
        minmap.draw(screen, reciveen, myplayer, recivepl)
        pygame.display.flip()

# main fuction                
if __name__ == "__main__":
    main()
    
