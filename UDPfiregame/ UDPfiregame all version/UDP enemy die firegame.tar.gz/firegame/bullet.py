import pygame
from pygame import *
from settings import *
import math

class Bullets(sprite.Sprite):
    def __init__(self, start, end, zoom, kof, atack, plid, num):
        sprite.Sprite.__init__(self)
        #ZOOM AND NAME
        self.name = "Player"
        self.zoom = ZOOM
        self.num = num
        self.atack = atack
        # surfaces
        self.image = Surface((BUL_SIZE, BUL_SIZE))
        self.rect = Rect(start[0], start[1], BUL_SIZE, BUL_SIZE)
        self.id = plid

        # position for move
        self.start = start
        self.end = end
        
        # SPEED VECTOR
        self.xvel = 0
        self.yvel = 0
        
        # DISTANCE FOR BEGIN
        self.posx = end[0] - start[0] +0.0
        self.posy = end[1] - start[1] +0.0

        #SPEED 
        self.velocity = VELOCITY

        #time from start
        self.time = time.get_ticks()

        self.mathxy = math.fabs(end[0] - start[0])+math.fabs(end[1] - start[1]) 
        #COEFICIENT FOR RESIZE
        kof = float(kof)/ZOOM
        # BULLET SIZE
        self.size = BUL_SIZE

        # IF ZOOM DECREASE BEFORE START FLY
        if kof <0:
            self.velocity = float(VELOCITY)/((1-kof)*(1-kof))
            self.size = float(BUL_SIZE)/(1-kof)
            
        # IF ZOOM INCREASE BEFORE START FLY    
        elif kof > 0:
            self.velocity = float(VELOCITY)*(1+kof)*(1+kof)
            self.size = float(BUL_SIZE)*(1+kof)

        # SPEED VECTOR FOR BULLET FLY    
        if self.mathxy != 0:
            self.xvel = self.velocity*(self.posx)/self.mathxy
            self.yvel = self.velocity*(self.posy)/self.mathxy
        
    def draw(self, screen):
        pygame.draw.circle(screen, (250,0,250), (self.rect.x, self.rect.y), int(self.size), int(self.size))

    def __del__(self):
        print "kill" 
    def updat(self, objects, zoom):
        
        # destroy at some time 
        if self.time + BULTIME <= time.get_ticks():
            self.kill()
            
        # IF ZOOM DECREASE DURING FLY     
        if self.zoom > zoom:
            self.velocity = self.velocity/KOF
            self.size = self.size/KOF
            
        # IF ZOOM INCREASE DURING FLY
        elif self.zoom < zoom:
            self.velocity = self.velocity*KOF
            self.size = self.size*KOF

        # CACLULATE NEW SPEED VECTOR DURING FLY
        if self.zoom != zoom:
            if self.mathxy!=0:
                self.xvel = self.velocity*(self.posx)/self.mathxy
                self.yvel = self.velocity*(self.posy)/self.mathxy   
                self.zoom = zoom
            
        # BULLET FLY
        self.rect.x = self.rect.x + self.xvel
        self.rect.y = self.rect.y + self.yvel
        

def findsqures(encord):
    xmin = encord[0][0]
    xmax = encord[0][0]
    ymin = encord[0][1]
    ymax = encord[0][1]
    for i in range(3):
        if xmin >= encord[i][0]:
            xmin = encord[i][0]
        if xmax <= encord[i][0]:
            xmax = encord[i][0]
        if ymin >= encord[i][1]:
            ymin = encord[i][1]
        if ymax <= encord[i][1]:
            ymax = encord[i][1]
    return (xmin, xmax, ymin, ymax)
