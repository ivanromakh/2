import random 
import pygame
from   pygame.locals import *
import psycopg2
import sys
import pickle
from time import sleep
import socket


import player
from player import* 
from settings import *
from pygame import *
from mapgenerator import generationmap
from menu import Menu, mennu
from minimap import Minimap


#draw a shift bullet 
def drawbull(screen, (x, y, plid, z), x1, y1):
    pygame.draw.circle(screen, (250,0,250), (x - int(x1), y - int(y1)),BUL_SIZE ,BUL_SIZE )


def move(p, x, y):
    p[0][0] = p[0][0] - x
    p[0][1] = p[0][1] - y
    p[1][0] = p[1][0] - x
    p[1][1] = p[1][1] - y 
    p[2][0] = p[2][0] - x
    p[2][1] = p[2][1] - y
    return p
    
def drawpoligon(screen, pos, zoom):
    pygame.draw.polygon(screen, PL_COLOR, ((pos[0]-zoom/2, pos[1]),(pos[0] + zoom/2, pos[1] - zoom/2),(pos[0] + zoom/2, pos[1] + zoom/2)))

def drawrect(screen, pos, zoom):
    pygame.draw.polygon(screen, PL_COLOR, ((pos[0]-zoom/2, pos[1]-zoom/2),(pos[0] -zoom/2, pos[1] + zoom/2),(pos[0] + zoom/2, pos[1] + zoom/2), (pos[0] + zoom/2, pos[1] - zoom/2)))

# draw information and fps  
def drawtext(screen, timer):
    mytext = pygame.font.SysFont("monospace", 15)
    timer.tick(40)
    text = mytext.render("FPS "+str(timer.get_fps()), 1, (10, 10, 10))
    screen.blit(text, (5, 160))
    
# main function
def main():

    pygame.init()
    
    # menu check server or client
    mennu()

    #zoom    
    zoom = ZOOM
    kof = 0
    
    #draw displey
    screen = pygame.display.set_mode(DISPLAY) 
    bg = Surface((zoom,zoom))
    # minimap
    minimap = Surface((MINIMAPSIZE,MINIMAPSIZE))

    # generation map    
    (maps, x, y) = generationmap(zoom)

    # get player start position
    midx = x/2
    midy = y/2
    
    # minimap create
    minmap = Minimap(zoom)
    
    #create this user 
    myplayer = player.Player(midx, midy, zoom, True, kof, False, CANNON)
    play_parts = pygame.sprite.Group()
    play_parts.add(myplayer)
    
    #this user bullets
    player_bul = pygame.sprite.Group()
    
    # clock for fps
    timer = pygame.time.Clock()
    
    # zoom press
    iszoomincres = False
    iszoomdecres = False
        
    # socket create
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.connect((HOST, PORT))
    
    # reciven players and enemies list 
    recivepl = []
    reciveen = []
    mustdelete = []
    damagesend = []
    reckilen = []
    # send list of this user bullets
    data = ""
    while True:
        
        #draw background on the screen 
        screen.fill(BACKGROUND_COLOR)
        print reckilen
        for enemy in reciveen:
            for kilen in reckilen:
                if enemy[3] == kilen:
                    print "-------"
                    print kilen
                    print enemy[3]
                    reciveen.remove(enemy)
        # SHOTTING and all for this player bullets
        # and killed enemies
        mybulsend = []
        damagesend = []
        #update and draw bullets   
        for bul in player_bul:
            bul.updat(0, zoom)
            bul.draw(screen)
            # check if bullet find a target
            for encord in reciveen:
                #find squere of enemy on the map 
                xmin = encord[0][0]
                xmax = encord[0][0]
                ymin = encord[0][1]
                ymax = encord[0][1]
                for i in range(3):
                    if xmin > encord[i][0]:
                        xmin = encord[i][0]
                    if xmax < encord[i][0]:
                        xmax = encord[i][0]

                    if ymin > encord[i][1]:
                        ymin = encord[i][1]
                    if ymax < encord[i][1]:
                        ymax = encord[i][1]

                #if bullet in the enemy squere kill bullet         
                if bul.rect.x >=  xmin+3 and bul.rect.x <= xmax-3:
                    if bul.rect.y >=  ymin+3 and bul.rect.y <= ymax-3:
                        damagesend.append(encord[3])
                        reciveen.remove(encord)
                        bul.kill()
                        
            #add bullet in send list    
            mybulsend.append((bul.rect.x+int(myplayer.myposx), bul.rect.y+int(myplayer.myposy), bul.id, bul.num))


            #CREATE PACKAGE FOR SEND
        #send thisplayer package
        data = "PL"
        myplayer.shiftmove()
        data += pickle.dumps(myplayer.sendp)
        #serialize thisplayer bullets    
        data += "BUL"
        data += pickle.dumps(mybulsend)
        #serialize damage of thisplayer bullets   
        data += "DAM"
        data += pickle.dumps(damagesend)
        
        #send and recive package
        sock.send(data)
        rec = sock.recv(BUFF)
    
        if rec[:2] == "PL":
            rec = rec[2:]
            cords = rec.split("BUL")

            #players
            players = pickle.loads(cords[0])
            for pl in players:
                if pl[3]!= myplayer.id:
                    for myp in recivepl:
                        if pl[3]== myp[3]:
                            recivepl.remove(myp)
                    recivepl.append(pl)

                    
            #take bullet other player
            cor = cords[1].split("ENE")
            
            bullets = pickle.loads(cor[0])
            
            if bullets != []:
                for b in bullets:
                    if myplayer.id != b[2]:
                        drawbull(screen, b, myplayer.myposx, myplayer.myposy)

            co = cor[1].split("KIL")

            #take enemy cords
            enemies = pickle.loads(co[0])
            for enemy in enemies:
                for myenemy in reciveen:
                    if enemy[3] == myenemy[3]:
                        reciveen.remove(myenemy)
                reciveen.append(enemy)

            # take id killen enemies
            reckilen = pickle.loads(co[1])
            print reckilen

        # draw recived players
        for p in recivepl:
            if p[4] == False:
                move(p,myplayer.myposx, myplayer.myposy)
                p[4] = True
            pldraw(screen, p, PL_COLOR) 


        # draw recived enemies
        for myenemy in reciveen:
            if myenemy[4] == False:
                myenemy = move(myenemy,myplayer.myposx, myplayer.myposy)
                myenemy[4] = True
            pldraw(screen, myenemy, EN_COLOR)

                
        #draw and update thisplayer object 
        pos = mouse.get_pos()
        for pl in play_parts:
            pl.update(0,zoom, myplayer)
            pl.draw(screen, pos, zoom)


        # ALL EVENTS for gamemode
        for e in pygame.event.get():
            # check multipress 
            keystate = pygame.key.get_pressed()

        
            # exit
            if e.type == QUIT:
                pygame.quit()
                sys.exit()

 
            # start moving and rotating
            elif e.type == KEYDOWN:
                if keystate[K_ESCAPE]:
                    pygame.quit()
                    sys.exit()
                if keystate[K_UP]:
                    for part in play_parts:
                        part.ismoveup = True
                if keystate[K_DOWN]:
                    for part in play_parts:
                        part.ismovedown = True
                if keystate[K_LEFT]:
                    for part in play_parts:
                        part.isrotateleft = True
                if keystate[K_RIGHT]:
                    for part in play_parts:
                        part.isrotateright = True
                if keystate[K_1]:
                    iszoomincres = True
                if keystate[K_2]:
                    iszoomdecres = True


            # stop moving and rotating        
            elif e.type == KEYUP:
                if e.key == K_UP:
                    for part in play_parts:
                        part.ismoveup = False
                if e.key == K_DOWN:
                    for part in play_parts:
                        part.ismovedown = False
                if e.key == K_LEFT:
                    for part in play_parts:
                        part.isrotateleft = False
                if e.key == K_RIGHT:
                    for part in play_parts:
                        part.isrotateright = False
                if e.key == K_1:
                    iszoomincres = False
                if e.key == K_2:
                    iszoomdecres = False

            #player shoot        
            elif e.type == pygame.MOUSEBUTTONDOWN:
                # player shoot
                for pl in play_parts:
                    if pl.ptype == CANNON:
                        player_bul.add(pl.shoot(pos, kof))

        
        drawtext(screen, timer)
        minmap.draw(screen, reciveen, myplayer, recivepl,  zoom)
        pygame.display.flip()



# main fuction                
if __name__ == "__main__":
    main()
    
