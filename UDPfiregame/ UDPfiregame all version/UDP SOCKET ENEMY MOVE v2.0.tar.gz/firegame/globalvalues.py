import random 
import pygame
from   pygame.locals import *
import psycopg2
import sys
import pickle
from time import sleep
import socket

# players cords on server
plbufer = []
enbuffer = []
