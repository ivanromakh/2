import threading
import socket
import logging
import pickle
import pygame
import random


from settings import*
import player



clients_lock = threading.Lock()


class Server():

    def __init__(self):
        logging.info('Initializing Broker')
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((HOST, PORT))
        self.i = 0
        
        pygame.init()

        self.recpl = []
        self.recbull = []
        self.senden = []
        self.en = pygame.sprite.Group()
        
        pygame.time.set_timer(ENEMYRATE, 4000)
        pygame.time.set_timer(EN_FIRE, 500)
    
    def enmove(self):
        # enemy updates
        for e in self.en:
            x = 6
            x = int(x*random.random())
            if x == 0:
                e.update(-1,ZOOM, 0)
                self.senden.remove(e.sendp)
                e.shiftmove()
                self.senden.append(e.sendp)
            if x == 1:
                e.rotate(1, ZOOM,0)
                self.senden.remove(e.sendp)
                e.shiftmove()
                self.senden.append(e.sendp)
            if x >= 2 and x <=5:
                e.update(1,ZOOM, 0)
                self.senden.remove(e.sendp)
                e.shiftmove()
                self.senden.append(e.sendp)
            if x == 6:
                e.rotate(1, ZOOM,0)
                self.senden.remove(e.sendp)
                e.shiftmove()
                self.senden.append(e.sendp)

    def GenEnemies(self):
        for e in pygame.event.get():
            if e.type ==  ENEMYRATE:
                myenemy = player.Player(
                    int(WIN_WIDTH/ZOOM*random.random()),
                    int(WIN_HEIGHT/ZOOM*random.random()),
                    ZOOM, False, 0, False, CANNON)
                
                self.senden.append(myenemy.sendp)
                self.en.add(myenemy)
    
    
    def talkToClient(self, ip):
        data = "PL"
        data += pickle.dumps(self.recpl)
        data += "BUL"
        data += pickle.dumps(self.recbull)
        data += "ENE"
        data += pickle.dumps(self.senden)   
        self.sock.sendto(data, ip)

    def listen_clients(self):
        while True:
            #generate enemies
            self.GenEnemies()
            #move enemies
            self.enmove()
            msg, client = self.sock.recvfrom(1024)
            self.decode(msg, self.recpl)
            t = threading.Thread(target=self.talkToClient, args=(client,))
            t.start()

    def decode(self, msg, plcords):
        # if this is player cords
        if msg[0:2] == "PL":
            msg = msg[2:]
            cords = msg.split("BUL")

            #players
            player = pickle.loads(cords[0])
            for pl in self.recpl:
                if player[3] == pl[3]:
                    self.recpl.remove(pl)
            self.recpl.append(player)
            #bullets
            bullets = pickle.loads(cords[1])
            for cor in bullets:
                for b in self.recbull:
                    if cor[3] == b[3]:
                        if cor[2] == b[2]:
                            self.recbull.remove(b)
                self.recbull.append(cor)
                
                             
if __name__ == '__main__':
    # Make sure all log messages show up
    logging.getLogger().setLevel(logging.DEBUG)
    print "start", HOST, PORT
    Ser = Server()
    Ser.listen_clients()
