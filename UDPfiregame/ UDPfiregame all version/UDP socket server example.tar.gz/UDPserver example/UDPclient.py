import socket
import sys
from time import sleep

HOST, PORT = "localhost", 4242
data = "xxxxx"
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.connect((HOST, PORT))
i = 0        
while i<2:
    i+=1
    # Connect to server and send data
    sock.sendall(data + "\n")
    # Receive data from the server and shut down
    received = sock.recv(1024)
    print "Received: %s"%received
