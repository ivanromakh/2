import pygame
import math
from pygame import *
import random

from settings import *
from bullet import Bullets
from objectmoving import *
from mygame4 import enzooming

class Player():
    def __init__(self, x, y, whoIam, ispart, ptype):
        self.whoIam = whoIam
        self.id = random.random()
        self.num = 0

        # part or player    
        self.ispart = ispart
        self.ptype = ptype

        #center
        self.center = []
        self.center.append(x)
        self.center.append(y)
        self.vec1 = [self.center[0] - ZOOM/2, self.center[1]]
        #alfa
        self.alfa = 0
        if whoIam == True:
            if self.ptype == CANNON:
                self.beta = 0
                self.speed = SPEED
                self.vec2 = [self.center[0] + ZOOM2, self.center[1]- ZOOM2]
                self.vec3 = [self.center[0] + ZOOM2, self.center[1] + ZOOM2]
                self.points = [self.vec1, self.vec2, self.vec3]
                self.myposx = 0.0
                self.myposy = 0.0
                self.spvec = [0.0, 0.0]
            if self.ptype == SHILD:
                self.shhealth = SHHEALTH
                # vectors of points
                
                self.vec1 = [self.center[0] - ZOOM2, self.center[1] - ZOOM2]
                self.vec2 = [self.center[0] + ZOOM2, self.center[1] - ZOOM2]
                self.vec3 = [self.center[0] + ZOOM2, self.center[1] + ZOOM2]
                self.vec4 = [self.center[0] - ZOOM2, self.center[1] + ZOOM2]
                self.points = [self.vec1, self.vec2, self.vec3, self.vec4]
                self.radius = SHHEALTH    
            
        # speed
        # if enemy
        if whoIam == False:
            self.speed = EN_SPEED
            self.points = [self.vec1]
            self.health = ENHEALTH
            self.radius = RANGE 
            self.atack = CAN_ATACK
            self.isrotated = False
            self.movex = 0
            self.movey = 0
            
        # if player
        if whoIam == True: 
            self.health = PHEALTH
            self.ismoveup = False
            self.ismovedown = False
            self.isrotateleft = False
            self.isrotateright = False
            self.partposx = 0
            self.partposy = 0
            self.atack = CAN_ATACK
            
        # if it is part     
        if ispart == True:
            # angle
            self.alfa = 0
            #position pasrt on player
            self.partposx = 0
            self.partposy = 0
            
    # draw poligon and cannon
    def draw(self, screen, pos, scale):
        dx = pos[0]-self.center[0]
        dy = pos[1]-self.center[1]
        rads = math.atan2(-dy,dx)
        rads %= 2*math.pi
        degs = 180-math.degrees(rads)
        if degs > self.beta:
            self.beta += TOWROT
        if degs < self.beta:    
            self.beta -= TOWROT

        rot_image1 = pygame.transform.rotozoom(image1, -self.alfa, 0.5)
        rot_image2 = pygame.transform.rotozoom(image2, -self.beta, 0.5)        
        x1 = rot_image1.get_rect()
        x2 = rot_image2.get_rect()
        screen.blit(rot_image1, (self.center[0]-x1[2]/2, self.center[1]-x1[3]/2))
        screen.blit(rot_image2, (self.center[0]-x2[2]/2, self.center[1]-x2[3]/2))
       
    # find new vector of speed
    # moving is cameramove in class Camera
    # moving is by this vector speed
    def move(self, speed):
        if self.whoIam == True:
            xy = math.fabs(self.points[0][0] - self.center[0])+math.fabs(self.points[0][1] - self.center[1])        
            x = 0
            y = 0
            if xy!=0:
                if self.spvec[0] <= MAXSPEED and self.spvec[0] >= -MAXSPEED:    
                    self.spvec[0] += self.speed*(self.points[0][0] - self.center[0])/xy
                if self.spvec[1] <= MAXSPEED and self.spvec[1] >= -MAXSPEED:
                    self.spvec[1] += self.speed*(self.points[0][1] - self.center[1])/xy
                   
        else:
            if self.isrotated == True:
                xy = math.fabs(self.points[0][0] - self.center[0])+math.fabs(self.points[0][1] - self.center[1])        
                x = 0
                y = 0
                if xy!=0:
                    self.movex = self.speed*(self.points[0][0] - self.center[0])/xy
                    self.movey = self.speed*(self.points[0][1] - self.center[1])/xy
                self.isrotated = False
                
            self.center[0] += self.movex
            self.center[1] += self.movey
            self.points[0][0] += self.movex
            self.points[0][1] += self.movey
              
    # move on map, change zoom, rotate all objects and player
    def update(self, speed, zoom, player):
        # move on map
        if self.whoIam == False and speed !=0:     
              self.move(speed)
        # if he is a player
        # rotate or move  
        if self.whoIam == True and self.ispart == False:
            
            if self.spvec[0] < SPEED_DEC and self.spvec[0] > -SPEED_DEC:
                self.spvec[0] = 0
            if self.spvec[0] > 0:
                self.spvec[0] -= SPEED_DEC*self.spvec[0]
            elif self.spvec[0] < 0:
                self.spvec[0] -= SPEED_DEC*self.spvec[0]
                
            if self.spvec[1] < SPEED_DEC and self.spvec[1] > -SPEED_DEC:
                self.spvec[1] = 0    
            if self.spvec[1] > 0:
                self.spvec[1] -= SPEED_DEC*self.spvec[1]
            elif self.spvec[1] < 0:
                self.spvec[1] -= SPEED_DEC*self.spvec[1]     

            print  self.spvec
            self.myposx += self.spvec[0]
            self.myposy += self.spvec[1]

            if self.ismoveup == True:
                self.move(speed*zoom)
                if self.isrotateleft == True:
                    self.rotate(-1,0)
                if self.isrotateright == True:
                    self.rotate(1, 0)
            if self.ismovedown == True:
                self.move(-speed*zoom)
                if self.isrotateleft == True:
                    self.rotate(-1,0)
                if self.isrotateright == True:
                    self.rotate(1, 0)
            
        if self.ispart == True:
            if self.isrotateleft == True:
                self.rotate(-1, player)
            if self.isrotateright == True:
                self.rotate(1, player)
            
    # rotate object around the center    
    def rotate(self, x, player):
        alfa = 0
        self.isrotated = True
        # increase all point angles
        if x>0:
            self.alfa += ALFA
            alfa = ALFA
        elif x<0:
            self.alfa -= ALFA
            alfa = -ALFA
        if alfa != 0:
            if self.ispart == True:
                #rotate poligon points
                self.points = rotatepoints(player.center, self.points, alfa)
                #self.center = findcent(self.alfa, self.points, self.center, self.ptype)
            else:    
                #rotate poligon points
                self.points = rotatepoints(self.center, self.points, alfa)

    # rotate object around the center    
    def rottoanhle(self, alfa, player):
        if self.ispart == True:
            self.points = rotatepoints(player.center, self.points, alfa)
            alfa = 0
        else:    
            self.points = rotatepoints(self.center, self.points, alfa)
     
    # create bullet in class Bullets
    def shoot(self, pos):
        x = 0
        y = 0
        angle = math.radians(self.beta)
        tn = math.tan(angle)
        print tn
        if self.beta>-90 and self.beta<90: 
            x = -100
            y = tn*x
        elif self.beta>90 or self.beta<-90:
            x = 100
            y = tn*x
            
        bul = Bullets(self.center, (self.center[0]+x, self.center[1]+y), self.atack, self.id, self.num)
        if self.num < 10:
            self.num += 1
        else:
            self.num = 0
        return bul

# draw recived player
def pldraw(screen, points, color):
    pygame.draw.polygon(screen, color, points)
    



