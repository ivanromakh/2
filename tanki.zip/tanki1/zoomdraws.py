import pygame
import math

from settings import ZOOM, BUL_SIZE, PL_COLOR, CAN_COLOR, CAN_SIZE, image1, image2
from objectmoving import rotatepoints

#find squere of enemy on the map 
def findsquere(encord):
    xmin = encord[0][0]-ZOOM/2
    xmax = encord[0][0]+ZOOM/2
    ymin = encord[0][1]-ZOOM/2
    ymax = encord[0][1]+ZOOM/2
    return (xmin, xmax, ymin, ymax)

def drawscbull(screen, (x, y), scale):
    pygame.draw.circle(screen, (250,0,250), (x, y), int(BUL_SIZE*scale) , int(BUL_SIZE*scale))

def drawmyen(screen, pos, alfa, myplcent, scale, color):
    tcords = []
    tcords.append([pos[0] - ZOOM/2, pos[1]])
    tcords.append([pos[0] + ZOOM/2, pos[1] - ZOOM/2])
    tcords.append([pos[0] + ZOOM/2, pos[1] + ZOOM/2])
    points = rotatepoints(pos, tcords, alfa)
    points = mypoints(points, myplcent, scale)
    dx = points[0][0]-pos[0]
    dy = points[0][1]-pos[1]

    rads = math.atan2(-dy,dx)
    degs = 180-math.degrees(rads)
    
    rot_image1 = pygame.transform.rotozoom(image1, -alfa, 0.5)
    rot_image2 = pygame.transform.rotozoom(image2, -degs, 0.5)        
    x1 = rot_image1.get_rect()
    x2 = rot_image2.get_rect()
    screen.blit(rot_image1, (pos[0]-x1[2]/2, pos[1]-x1[3]/2))
    screen.blit(rot_image2, (pos[0]-x2[2]/2, pos[1]-x2[3]/2))

def drawmypl(screen, pos, alfa, myplcent, scale, color, canpos):
    tcords = []
    tcords.append([pos[0] - ZOOM/2, pos[1]])
    tcords.append([pos[0] + ZOOM/2, pos[1] - ZOOM/2])
    tcords.append([pos[0] + ZOOM/2, pos[1] + ZOOM/2])

    points = rotatepoints(pos, tcords, alfa)
    points = mypoints(points, myplcent, scale)
    dx = canpos[0]-pos[0]
    dy = canpos[1]-pos[1]

    rads = math.atan2(-dy,dx)
    degs = 180-math.degrees(rads)
    
    rot_image1 = pygame.transform.rotozoom(image1, -alfa, 0.5)
    rot_image2 = pygame.transform.rotozoom(image2, -degs, 0.5)
    
    x1 = rot_image1.get_rect()
    x2 = rot_image2.get_rect()
    screen.blit(rot_image1, (pos[0]-x1[2]/2, pos[1]-x1[3]/2))
    screen.blit(rot_image2, (pos[0]-x2[2]/2, pos[1]-x2[3]/2))
       
    

def drawpoligon(screen, pos):
    pygame.draw.polygon(screen, PL_COLOR, ((pos[0] - ZOOM/2, pos[1]),
                                           (pos[0] + ZOOM/2, pos[1] - ZOOM/2),
                                           (pos[0] + ZOOM/2, pos[1] + ZOOM/2)))

def drawrect(screen, pos):
    pygame.draw.polygon(screen, PL_COLOR, ((pos[0] - ZOOM/2, pos[1] - ZOOM/2),
                                           (pos[0] - ZOOM/2, pos[1] + ZOOM/2),
                                           (pos[0] + ZOOM/2, pos[1] + ZOOM/2),
                                           (pos[0] + ZOOM/2, pos[1] - ZOOM/2)))

# draw information and fps  
def drawtext(screen, timer):
    mytext = pygame.font.SysFont("monospace", 15)
    timer.tick(60)
    text = mytext.render("FPS "+str(timer.get_fps()), 1, (10, 10, 10))
    screen.blit(text, (5, 160))

#zooming recived players objects
def enzooming(obj, center, scale):
    dis = mypoints(obj, center, scale)
    return dis

#zooming bullet
def bzooming(obj, center, x, y, scale):
    dis = mypoint(obj, center, x, y, scale)
    return dis

#shift points by player moving and zooming
def mypoints(points, center, scale):
    newp = []
    for p in points: 
        newp.append((int(center[0]+((p[0]-center[0])*scale)), int(center[1]+((p[1]-center[1])*scale))))
    return newp

#shift point by player moving and zooming
def mypoin(p, center, scale):
    return (int(center[0]+((p[0]-center[0])*scale)), int(center[1]+((p[1]-center[1])*scale)))


#shift point by player moving and zooming
def mypoint(p, center, x, y, scale):
    return (int(center[0]+((p[0]-center[0]-x)*scale)), int(center[1]+((p[1]-center[1]-y)*scale)))
